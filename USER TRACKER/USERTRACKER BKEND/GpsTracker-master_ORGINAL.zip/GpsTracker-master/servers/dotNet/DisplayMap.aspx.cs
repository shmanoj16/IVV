
using System;
using System.Web.UI;

public partial class DisplayMap : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
    }
}
