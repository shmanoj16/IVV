<div class="wrap">
	<h3>Gps Tracker Settings</h3>
	<div class="wrap">
    <p>To use this plugin, add this shortcode to any page or post:</p> 
    <p>[gps_tracker]</p>     
    <p><a href="https://play.google.com/store/apps/details?id=com.websmithing.wp.gpstracker&hl=en">Download the Android app from the Google play store</a> using your Android cell phone</p>
    
    <p>and enter your user name and this url in the download website text box:
    </p>
    <?php echo site_url(); ?>      
	</div>
</div>