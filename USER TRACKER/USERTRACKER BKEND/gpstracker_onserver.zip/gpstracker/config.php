<?php
$con =new mysqli("mysql.hostinger.in", "u173800516_mouni", "ivv123","u173800516_ivv");
if($con->connect_errno)
{
	echo $con->connect_errno;
	die("Error");
}
